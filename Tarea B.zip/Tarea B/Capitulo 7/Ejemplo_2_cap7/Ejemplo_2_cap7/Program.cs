﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo_2_cap7
{
    /// 2 Hacer un programa que funcione como un diccionario, con palabra y definición,usando el Hashtable.
   
    class Diccionario
    {
      public static void Main(string[] args)
        {
            Hashtable palabras = new Hashtable();
            palabras.Add("Abandonar", "Dejar solo, sin atención, sin cuidados a una persona, un animal o una cosa.");
            palabras.Add("Abanico", "Objeto que sirve para dar aire.");
            palabras.Add("Abeto", "Árbol de tronco alto y recto. La copa tiene forma de cono y su fruto son las piñas. ");
            palabras.Add("Caño", "Tubo por donde sale al exterior un chorro de un líquido.");

            foreach (DictionaryEntry datos in palabras)
                Console.WriteLine(datos.Key + ":\t" + datos.Value);
        }



    }
}